# VideoChatWebApp-using-Jitsi-API
How to create a video chat web app using API

[Link to Youtube video](https://youtu.be/n3wp0xhap2k)
![Capture](https://user-images.githubusercontent.com/43510126/121779071-8245d380-cbb7-11eb-8672-53d0aaa19898.PNG)


